/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritthewind;

/**
 *
 * @author krigsdator
 */
class Cloud {
    /**
     * 
     * @param ifClouds gives a number that will determine how dense the cloud 
     * cover is
     * @return the density of the cloud cover
     */
    public String cloudReturn(int ifClouds) {
        String clouds = null;
        if (ifClouds == 1) {
            clouds = "None";
        } else if (ifClouds == 2) {
            clouds = "Light";
        } else if (ifClouds == 3) {
            clouds = "Medium";
        } else if (ifClouds == 4) {
            clouds = "Heavy";
        }
        return clouds;
    }
    /**
     * 
     * @param whatDirection gives a number to determine the wind direction
     * @return returns the wind direction
     */
    public String windDirection(int whatDirection) {
        if (whatDirection == 1) {
            return "N";
        }
        if (whatDirection == 2) {
            return "S";
        }
        return null;
    }
    /**
     * 
     * @param miles the amount of miles given
     * @return the amount of kilometers to the amount of miles
     */
    public int toKilometers(double miles) {
        return (int) (Math.round(miles * 1.609));
    }
    /**
     * 
     * @param whatRain gives a number to determine the type of precipitation
     * @return returns the type of precipitation
     */
    public String precipitation(int whatRain) {
        if (whatRain == 1) {
            return "None";
        } else if (whatRain == 2) {
            return "Rain";
        } else if (whatRain == 3) {
            return "Snow";
        }
        return null;
    }
    /**
     * 
     * @param inches gives the amount of inches
     * @return returns the amount of centimeters to inches
     */
    public int toCentimeters(double inches) {
        return (int) (Math.round(inches * 2.54));
    }
}
