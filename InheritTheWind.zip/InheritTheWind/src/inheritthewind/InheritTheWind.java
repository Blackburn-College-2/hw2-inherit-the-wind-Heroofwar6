/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritthewind;

/**
 *
 * @author krigsdator
 */
public class InheritTheWind {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Weather weather = new Weather();
        System.out.println("Welcome to Weather-Tron. Here's your report:");
        System.out.println("");
        weather.printWeather();
    }

}
