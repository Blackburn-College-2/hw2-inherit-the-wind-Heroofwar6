/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritthewind;

/**
 *
 * @author krigsdator
 */
public class Weather extends Temperature {

    int morningTemp = (int) ((Math.random() * 21) + 50);
    int ifCloud;
    String morningTempPrinted;
    String ifCloudPrinted;
    int windDirection;
    int windSpeed;
    int rain;
    String rainPrint;
    /**
     * creates a random number for the variables in printWeather()
     */
    public void makeRandom() {
        for (int i = 0; i < 1; i++) {
            this.rain = (int) ((Math.random() * 3) + 1);
            this.windSpeed = (int) ((Math.random() * 20) + 1);
            this.windDirection = (int) ((Math.random() * 2) + 1);
            this.ifCloud = (int) ((Math.random() * 4) + 1);
        }
    }
    /**
     * prints out the temp and clouds from morning to midday
     */
    public void printMorning(){
        morningTempPrinted = super.tempReturnMorn(morningTemp);
            ifCloudPrinted = super.cloudReturn(ifCloud);
            System.out.println("Morning Temperature: " + morningTempPrinted);
            System.out.println("Clouds: " + ifCloudPrinted);
            this.setChange();
            morningTempPrinted = super.tempReturnMorn(morningTemp);
            System.out.println("Midday Temperature: " + morningTempPrinted);
    }
    /**
     * prints out the precipitation
     */
    public void printRain(){
        rainPrint = super.precipitation(rain);
            System.out.print("Precipitation: ");
            if (rainPrint.equals("None")) {
                System.out.println(rainPrint);
            }else{
            this.whatRain();
            }
    }
    /**
     * decides what precipitation will fall
     */
    public void whatRain(){        
            int gathered = (int) ((Math.random() * 25) + 1);
            if (rainPrint.equals("Rain")) {
                System.out.println(super.toCentimeters(gathered) + " cm/"
                        + gathered + " in " + rainPrint);
                morningTemp = (int) (morningTemp
                        - (super.toCentimeters(0.9 / gathered)));
            } else if (rainPrint.equals("Snow")) {
                System.out.println(super.toCentimeters(gathered) + " cm/"
                        + gathered + " in " + rainPrint);
                morningTemp = (int) (morningTemp
                        - (super.toCentimeters(0.15 / gathered)));
            }
    }
    /**
     * prints the wind speed and direction
     */
    public void printWind(){
        System.out.println("Wind: " + super.toKilometers(windSpeed)
                    + " kph/" + windSpeed + " mph "
                    + super.windDirection(windDirection));
            if (windDirection == 1) {
                morningTemp = (int) (morningTemp
                        - (super.toKilometers(0.65 / windSpeed)));
            } else if (windDirection == 2) {
                morningTemp = (int) (morningTemp
                        + (super.toKilometers(0.5 / windSpeed)));
            }
    }
    /**
     * prints the weather and calls all the print methods
     */
    public void printWeather() {
        for (int i = 0; i < 10; i++) {
            this.makeRandom();
            System.out.println("Day " + (i + 1) + ":");
            this.printMorning();            
            this.printRain();
            this.printWind();
            System.out.println("");
        }
    }
    /**
     * 
     * @return the change in midday temperature
     */
    public int setChange() {
        int change = 0;
        if (ifCloud == 1) {
            change = 6;
        } else if (ifCloud == 2) {
            change = 3;
        } else if (ifCloud == 3) {
            change = -3;
        } else if (ifCloud == 4) {
            change = -14;
        }
        morningTemp = morningTemp + change;
        return change;
    }
}
