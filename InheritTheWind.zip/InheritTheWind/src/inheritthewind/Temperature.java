/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritthewind;

/**
 *
 * @author krigsdator
 */
public class Temperature extends Cloud {

    int initialF;
    int initialC;
    /**
     * 
     * @param initialF the initial temperature in farenheit
     * @return 
     */
    public String tempReturnMorn(int initialF) {
        this.initialF = initialF;
        this.initialC = Math.round(initialF - 32) * 5 / 9;
        return initialC + " C/ " + initialF + " F";
    }
}
